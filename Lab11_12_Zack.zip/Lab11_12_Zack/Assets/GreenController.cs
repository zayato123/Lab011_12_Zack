﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GreenController : MonoBehaviour
{
    public GameObject healthtext;
    public float speed = 10.0f;
    public float rotatespeed = 5.0f;
    public float damageRate = 5.0f;
    public float health = 10.0f;
    public Animator animator;
    Vector3 pos;
    public bool js;
    // Start is called before the first frame update
    void Start()
    { 
        animator = GetComponent<Animator>();
        js = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            transform.position += transform.forward * speed * Time.deltaTime;
            transform.rotation = Quaternion.Euler(0, 0, 0);
            animator.SetBool("Walk", true);
        }
        else if (Input.GetKey(KeyCode.S))
        {

            transform.position += new Vector3(0, 0, Time.deltaTime * -speed);
            animator.SetBool("Walk", true);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.Translate(Vector3.forward * Time.deltaTime * speed);

            transform.rotation = Quaternion.Euler(0, 90, 0);
            animator.SetBool("Walk", true);
        }
        else if (Input.GetKey(KeyCode.A))
        {
            transform.Translate(Vector3.forward * Time.deltaTime * speed);

            transform.rotation = Quaternion.Euler(0, -90, 0);
            animator.SetBool("Walk", true);
        }
        else if (Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.S) || Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.W)) 
        {
            animator.SetBool("Walk", false);
        }
        if(Input.GetKeyDown(KeyCode.Space))
        {
            animator.SetTrigger("Attack");
        }
       
        if (js == true)
        {
            transform.position = pos;
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        healthtext.GetComponent<Text>().text = "Health: " + health.ToString("F0");

    }
     void OnTriggerStay(Collider other)
    {
        if (other.gameObject.tag == "Fire")
        {
            health -= damageRate * Time.deltaTime;
           
        }
        if (health <= 0 && js == false)
        {
            animator.SetTrigger("Death");
            pos = new Vector3(transform.position.x, transform.position.y, transform.position.z);
            js = true;

        }


    }
}

